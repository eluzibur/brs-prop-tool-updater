# Setup / Notes

To get JsonConverter working: 
* Developer > Visual Basic > Right Click Project > Import File > Add 'JsonConverter.bas' 
* Developer > Visual Basic > Tools (Top Menu) > References > Enable "Microsoft Scripting Runtime"